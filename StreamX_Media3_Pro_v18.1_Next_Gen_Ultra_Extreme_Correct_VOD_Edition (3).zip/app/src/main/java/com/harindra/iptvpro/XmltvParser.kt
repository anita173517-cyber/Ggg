package com.harindra.iptvpro

import android.util.Log
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.Reader
import java.io.StringReader
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.ConcurrentHashMap

/**
 * StreamX Media3 Pro v17.0 Ultra Extreme Edition — XMLTV & EPG Engine.
 *
 * - Zero-SimpleDateFormat UTC + Timezone Offset parser.
 * - Extracts Now & Next programme titles, descriptions (<desc>), and live progress percentage.
 * - Normalized channel-ID & channel-name fuzzy key indexing for high-accuracy EPG matching.
 */
object XmltvParser {
    private const val MAX_DETAIL_ENTRIES = 8_000
    private val programmeDetailsMap = ConcurrentHashMap<String, EpgProgrammeDetail>(1024)

    fun trimProgrammeDetailsCache() {
        programmeDetailsMap.clear()
    }

    fun getProgrammeDetail(key: String?): EpgProgrammeDetail? {
        if (key.isNullOrBlank()) return null
        programmeDetailsMap[key]?.let { return it }
        programmeDetailsMap[key.lowercase(Locale.ROOT)]?.let { return it }
        val norm = normalizeEpgKey(key)
        if (norm.isNotEmpty()) {
            programmeDetailsMap[norm]?.let { return it }
        }
        return null
    }

    /**
     * Normalizes an EPG channel ID or channel name by lowercasing, stripping common country/quality
     * suffixes (.in, .uk, .us, hd, fhd, 4k), and retaining only alphanumeric characters.
     */
    fun normalizeEpgKey(raw: String?): String {
        if (raw.isNullOrBlank()) return ""
        val cleaned = raw.lowercase(Locale.ROOT)
            .removeSuffix(".in")
            .removeSuffix(".uk")
            .removeSuffix(".us")
            .removeSuffix(".ca")
            .removeSuffix(".au")
            .removeSuffix("_hd")
            .removeSuffix("-hd")
            .removeSuffix(" hd")
            .removeSuffix(" fhd")
            .removeSuffix(" 4k")
        val sb = StringBuilder(cleaned.length)
        for (i in 0 until cleaned.length) {
            val c = cleaned[i]
            if ((c in 'a'..'z') || (c in '0'..'9')) {
                sb.append(c)
            }
        }
        return sb.toString()
    }

    private fun formatUtcHm(epochMs: Long, localCalendar: Calendar): String {
        if (epochMs <= 0L) return ""
        localCalendar.timeInMillis = epochMs
        val h = localCalendar.get(Calendar.HOUR_OF_DAY)
        val m = localCalendar.get(Calendar.MINUTE)
        return String.format(Locale.US, "%02d:%02d", h, m)
    }

    fun parseNowNext(
        xml: String,
        relevantChannelIds: Set<String>? = null,
        shouldCancel: () -> Boolean = { false }
    ): Map<String, Pair<String, String>> {
        return parseNowNext(StringReader(xml), relevantChannelIds, shouldCancel)
    }

    private data class CurrentProgRecord(
        val title: String,
        val desc: String,
        val startMs: Long,
        val stopMs: Long
    )

    fun parseNowNext(
        reader: Reader,
        relevantChannelIds: Set<String>? = null,
        shouldCancel: () -> Boolean = { false }
    ): Map<String, Pair<String, String>> {
        val parser = Xml.newPullParser()
        parser.setInput(reader)

        val normalizedRelevantIds: Set<String>? = relevantChannelIds?.let { ids ->
            val set = HashSet<String>(ids.size * 2)
            for (id in ids) {
                set.add(id)
                set.add(id.lowercase(Locale.ROOT))
                val norm = normalizeEpgKey(id)
                if (norm.isNotEmpty()) set.add(norm)
            }
            set
        }

        val now = System.currentTimeMillis()
        val currentMap = HashMap<String, CurrentProgRecord>(1024)
        val nextMap = HashMap<String, Pair<Long, String>>(1024)
        val displayNameToChannelId = HashMap<String, String>(1024)
        val cal = Calendar.getInstance(TimeZone.getTimeZone("UTC"))
        val localCal = Calendar.getInstance()

        var event = parser.eventType
        var activeChannelTagId = ""
        var inChannelTag = false
        var channelId = ""
        var start = ""
        var stop = ""
        var title = ""
        var desc = ""
        var inProgramme = false
        var skipCurrentProgramme = false
        var tagCounter = 0

        try {
            while (event != XmlPullParser.END_DOCUMENT) {
                tagCounter++
                if (tagCounter % 2000 == 0 && shouldCancel()) break

                when (event) {
                    XmlPullParser.START_TAG -> when (parser.name) {
                        "channel" -> {
                            activeChannelTagId = parser.getAttributeValue(null, "id")?.trim().orEmpty()
                            inChannelTag = activeChannelTagId.isNotEmpty()
                        }
                        "display-name" -> if (inChannelTag && activeChannelTagId.isNotEmpty()) {
                            val dName = runCatching { parser.nextText().trim() }.getOrDefault("")
                            if (dName.isNotEmpty() && displayNameToChannelId.size < 15_000) {
                                displayNameToChannelId.putIfAbsent(dName.lowercase(Locale.ROOT), activeChannelTagId)
                            }
                        }
                        "programme" -> {
                            channelId = parser.getAttributeValue(null, "channel")?.trim().orEmpty()
                            skipCurrentProgramme = channelId.isEmpty() ||
                                (normalizedRelevantIds != null &&
                                    !normalizedRelevantIds.contains(channelId) &&
                                    !normalizedRelevantIds.contains(channelId.lowercase(Locale.ROOT)) &&
                                    !normalizedRelevantIds.contains(normalizeEpgKey(channelId)))
                            if (!skipCurrentProgramme) {
                                inProgramme = true
                                start = parser.getAttributeValue(null, "start").orEmpty()
                                stop = parser.getAttributeValue(null, "stop").orEmpty()
                                title = ""
                                desc = ""
                            } else {
                                inProgramme = false
                            }
                        }
                        "title" -> if (inProgramme && title.isEmpty()) {
                            title = parser.nextText().trim()
                        }
                        "desc" -> if (inProgramme && desc.isEmpty()) {
                            desc = parser.nextText().trim().take(240)
                        }
                    }
                    XmlPullParser.END_TAG -> when (parser.name) {
                        "channel" -> {
                            inChannelTag = false
                            activeChannelTagId = ""
                        }
                        "programme" -> if (inProgramme) {
                            if (channelId.isNotEmpty() && title.isNotEmpty()) {
                                val startMs = parseXmltvTimestampFast(start, cal)
                                val stopMs = parseXmltvTimestampFast(stop, cal)
                                if (startMs > 0L && stopMs > startMs) {
                                    if (now in startMs until stopMs) {
                                        currentMap[channelId] = CurrentProgRecord(title, desc, startMs, stopMs)
                                    } else if (startMs > now) {
                                        val existingNext = nextMap[channelId]
                                        if (existingNext == null || startMs < existingNext.first) {
                                            nextMap[channelId] = startMs to title
                                        }
                                    }
                                }
                            }
                            inProgramme = false
                        }
                    }
                }
                event = parser.next()
            }
        } catch (e: Exception) {
            Log.w("StreamX", "XMLTV stream parse warning", e)
        }

        val allIds = HashSet<String>(currentMap.size + nextMap.size).apply {
            addAll(currentMap.keys)
            addAll(nextMap.keys)
        }
        val result = HashMap<String, Pair<String, String>>(allIds.size * 2)
        for (id in allIds) {
            val curRec = currentMap[id]
            val curTitle = curRec?.title ?: "No current listing"
            val nxtTitle = nextMap[id]?.second ?: "No upcoming listing"
            val pair = curTitle to nxtTitle
            val lowerId = id.lowercase(Locale.ROOT)
            val normId = normalizeEpgKey(id)

            result[id] = pair
            result.putIfAbsent(lowerId, pair)
            if (normId.isNotEmpty()) {
                result.putIfAbsent(normId, pair)
            }

            if (curRec != null && programmeDetailsMap.size < MAX_DETAIL_ENTRIES) {
                val duration = (curRec.stopMs - curRec.startMs).coerceAtLeast(1L)
                val elapsed = (now - curRec.startMs).coerceIn(0L, duration)
                val pct = ((elapsed * 100L) / duration).toInt().coerceIn(5, 100)
                val windowStr = "${formatUtcHm(curRec.startMs, localCal)} - ${formatUtcHm(curRec.stopMs, localCal)}"
                val detail = EpgProgrammeDetail(
                    nowTitle = curTitle,
                    nextTitle = nxtTitle,
                    description = curRec.desc,
                    timeWindow = windowStr,
                    progressPercent = pct
                )
                programmeDetailsMap[id] = detail
                programmeDetailsMap.putIfAbsent(lowerId, detail)
                if (normId.isNotEmpty()) {
                    programmeDetailsMap.putIfAbsent(normId, detail)
                }
            }
        }

        // Also index display-name aliases mapped from <channel id="..."><display-name>...</display-name></channel>
        for ((dispLower, chId) in displayNameToChannelId) {
            val mappedPair = result[chId] ?: result[chId.lowercase(Locale.ROOT)]
            if (mappedPair != null) {
                result.putIfAbsent(dispLower, mappedPair)
                val normDisp = normalizeEpgKey(dispLower)
                if (normDisp.isNotEmpty()) {
                    result.putIfAbsent(normDisp, mappedPair)
                }
            }
        }

        return result
    }

    /**
     * Zero-SimpleDateFormat parser for XMLTV timestamps ("yyyyMMddHHmmss +0000" or "yyyyMMddHHmmss").
     */
    fun parseXmltvTimestampFast(raw: String, utcCalendar: Calendar): Long {
        val s = raw.trim()
        if (s.length < 14) return -1L
        for (i in 0 until 14) {
            if (s[i] < '0' || s[i] > '9') return -1L
        }
        val year = (s[0] - '0') * 1000 + (s[1] - '0') * 100 + (s[2] - '0') * 10 + (s[3] - '0')
        val month = (s[4] - '0') * 10 + (s[5] - '0') - 1
        val day = (s[6] - '0') * 10 + (s[7] - '0')
        val hour = (s[8] - '0') * 10 + (s[9] - '0')
        val minute = (s[10] - '0') * 10 + (s[11] - '0')
        val second = (s[12] - '0') * 10 + (s[13] - '0')

        utcCalendar.clear()
        utcCalendar.set(year, month, day, hour, minute, second)
        var timeMs = utcCalendar.timeInMillis

        // Parse optional timezone offset e.g. "+0530", "-0400", or "+05:30"
        var idx = 14
        while (idx < s.length && s[idx] == ' ') idx++
        if (idx < s.length && (s[idx] == '+' || s[idx] == '-')) {
            val sign = if (s[idx] == '+') 1 else -1
            val rem = s.substring(idx + 1).replace(":", "").trim()
            if (rem.length >= 4 && rem.substring(0, 4).all { it in '0'..'9' }) {
                val tzH = (rem[0] - '0') * 10 + (rem[1] - '0')
                val tzM = (rem[2] - '0') * 10 + (rem[3] - '0')
                if (tzH in 0..14 && tzM in 0..59) {
                    val offsetMillis = sign * ((tzH * 60L + tzM) * 60_000L)
                    timeMs -= offsetMillis
                }
            }
        }
        return timeMs
    }
}
