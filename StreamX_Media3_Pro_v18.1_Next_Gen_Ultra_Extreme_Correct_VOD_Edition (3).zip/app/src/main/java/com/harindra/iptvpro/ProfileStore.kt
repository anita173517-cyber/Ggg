package com.harindra.iptvpro

import android.content.Context
import android.content.SharedPreferences
import android.util.Base64
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Locale
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

enum class ProfileType { M3U, XTREAM }

data class PlaylistProfile(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val type: ProfileType,
    val source: String,
    val username: String = "",
    val password: String = ""
)

/**
 * StreamX Media3 Pro v18.1 Ultra Upgrade — ProfileStore with Strict Per-Account Isolation & Comprehensive Settings:
 * - Encrypted credentials (`EncryptedSharedPreferences` + AES-256-GCM fallback).
 * - Salted SHA-256 4-digit Parental PIN lock.
 * - Per-account Continue Watching progress (`savePlaybackProgress`, `getContinueWatchingEntries`)
 *   strictly restricted to VOD Movies (`XTREAM_VOD_MOVIE`) and Series Episodes (`XTREAM_SERIES_EPISODE`).
 *   Live TV channels (`M3U_LIVE`, `XTREAM_LIVE`) NEVER enter Continue Watching.
 * - Per-account Watched / Unwatched history & season watched markers.
 * - Per-account Personal Watchlist separated for Movies (`getMovieWatchlistIds`) and Series (`getSeriesWatchlistIds`).
 * - Per-account Custom Channel Collections, Hidden Channels, Custom Channel Names, and EPG Reminders.
 * - Live TV Background Playback Management settings (`isStopLiveTvInBackgroundEnabled`, `isAutoReconnectLiveTvOnReturnEnabled`).
 * - Configurable Seek Step, VOD Playback Speed, UI Density, Overscan Safe-Area Margin, 12h/24h Clock, High-Contrast, Screensaver, and Remote Shortcuts.
 */
class ProfileStore(context: Context) {
    private val appContext = context.applicationContext
    private val fastMetaPrefs: SharedPreferences =
        appContext.getSharedPreferences("iptv_pro_prefs", Context.MODE_PRIVATE)

    @Volatile
    private var usingFallbackPrefs: Boolean = false

    // Lazy initialization: Tink/KeyStore is NEVER loaded on cold boot if the user has no saved profiles
    private val securePrefs: SharedPreferences by lazy {
        try {
            usingFallbackPrefs = false
            EncryptedSharedPreferences.create(
                appContext,
                "streamx_secure_profiles",
                MasterKey.Builder(appContext).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            usingFallbackPrefs = true
            Log.w("StreamX", "EncryptedSharedPreferences unavailable on this TV; using AES-GCM protected fallback")
            appContext.getSharedPreferences("streamx_profiles_fallback", Context.MODE_PRIVATE)
        }
    }

    @Volatile
    private var cachedProfiles: MutableList<PlaylistProfile>? = null

    private val cachedProgressByScope = HashMap<String, MutableMap<String, PlaybackProgressEntry>>(4)

    companion object {
        private const val PIN_HASH_KEY = "parental_pin_hash_v2"
        private const val PIN_SALT_KEY = "parental_pin_salt_v2"
        private const val LEGACY_PIN_KEY = "parental_pin_code"
        private const val FALLBACK_ENC_PREFIX = "ENC1:"
        private const val PLAYBACK_PROGRESS_PREFIX = "vod_series_progress_v181_"
        private const val MOVIE_WATCHLIST_PREFIX = "movie_watchlist_v181_"
        private const val SERIES_WATCHLIST_PREFIX = "series_watchlist_v181_"
        private const val LIVE_FAVORITES_PREFIX = "live_favorites_v181_"
        private const val WATCHED_HISTORY_PREFIX = "watched_history_v190_"
        private const val HIDDEN_CHANNELS_PREFIX = "hidden_channels_v190_"
        private const val CUSTOM_CHANNEL_NAMES_PREFIX = "custom_ch_names_v190_"
        private const val CUSTOM_GROUPS_PREFIX = "custom_ch_groups_v190_"
        private const val EPG_REMINDERS_PREFIX = "epg_reminders_v190_"
        private const val SEARCH_HISTORY_KEY = "unified_search_history_v18"
        private const val PERFORMANCE_MODE_KEY = "performance_mode_id_v18"
        private const val AUTO_NEXT_EPISODE_KEY = "auto_next_episode_enabled_v181"
        private const val STOP_LIVE_BG_KEY = "stop_live_tv_in_background_v190"
        private const val AUTO_RECONNECT_LIVE_RETURN_KEY = "auto_reconnect_live_on_return_v190"
        private const val SEEK_STEP_MS_KEY = "vod_seek_step_ms_v190"
        private const val VOD_SPEED_KEY = "vod_playback_speed_v190"
        private const val UI_DENSITY_KEY = "ui_density_mode_v190"
        private const val OVERSCAN_MARGIN_DP_KEY = "tv_overscan_margin_dp_v190"
        private const val CLOCK_24H_KEY = "clock_24h_enabled_v190"
        private const val HIGH_CONTRAST_KEY = "high_contrast_text_v190"
        private const val SCREENSAVER_MINS_KEY = "idle_screensaver_mins_v190"
        private const val STARTUP_DEST_KEY = "startup_destination_v190"
        private const val LONG_PRESS_OK_KEY = "remote_long_press_ok_v190"
        private const val PERSONALIZATION_KEY = "home_personalization_v190"
        private const val SETUP_WIZARD_DONE_KEY = "setup_wizard_completed_v190"
        private const val AUDIO_BOOST_DB_KEY = "audio_loudness_boost_db_v192"
        private const val PICTURE_MODE_KEY = "picture_brightness_mode_v192"
        private const val PINNED_CHANNELS_PREFIX = "pinned_channels_v192_"
        private const val MAX_PROGRESS_ITEMS = 120
        private const val MAX_SEARCH_HISTORY = 12

        fun sanitizeExternalInput(raw: String): String {
            if (raw.isEmpty()) return ""
            return raw
                .replace("\u200B", "")
                .replace("\uFEFF", "")
                .trim()
        }

        fun computeSaltedPinHash(pin: String, saltHex: String): String {
            val md = MessageDigest.getInstance("SHA-256")
            var digest = "$saltHex:${pin.trim()}".toByteArray(Charsets.UTF_8)
            repeat(1000) {
                md.reset()
                md.update(digest)
                digest = md.digest()
            }
            return digest.joinToString("") { "%02x".format(it) }
        }

        fun verifySaltedPinHash(candidatePin: String, saltHex: String, expectedHashHex: String): Boolean {
            if (candidatePin.length != 4 || expectedHashHex.isBlank() || saltHex.isBlank()) return false
            val actualHashHex = computeSaltedPinHash(candidatePin, saltHex)
            return MessageDigest.isEqual(
                actualHashHex.toByteArray(Charsets.UTF_8),
                expectedHashHex.toByteArray(Charsets.UTF_8)
            )
        }
    }

    fun normalizeScope(accountScope: String?): String {
        val raw = accountScope?.trim().orEmpty().ifBlank { activeId().orEmpty().ifBlank { "default" } }
        return raw.take(48).map { c ->
            if (c.isLetterOrDigit() || c == '_' || c == '-') c else '_'
        }.joinToString("")
    }

    private fun getOrCreateFallbackAesKey(): SecretKeySpec {
        var seedHex = fastMetaPrefs.getString("fallback_kdf_seed", null)
        if (seedHex.isNullOrBlank()) {
            val randomBytes = ByteArray(16)
            SecureRandom().nextBytes(randomBytes)
            seedHex = randomBytes.joinToString("") { "%02x".format(it) }
            fastMetaPrefs.edit().putString("fallback_kdf_seed", seedHex).apply()
        }
        val keyBytes = MessageDigest.getInstance("SHA-256")
            .digest(("StreamX_AES256_${appContext.packageName}_$seedHex").toByteArray(Charsets.UTF_8))
        return SecretKeySpec(keyBytes, "AES")
    }

    private fun encryptFallbackPayload(plainJson: String): String {
        return try {
            val iv = ByteArray(12)
            SecureRandom().nextBytes(iv)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateFallbackAesKey(), GCMParameterSpec(128, iv))
            val cipherBytes = cipher.doFinal(plainJson.toByteArray(Charsets.UTF_8))
            val combined = ByteArray(iv.size + cipherBytes.size)
            System.arraycopy(iv, 0, combined, 0, iv.size)
            System.arraycopy(cipherBytes, 0, combined, iv.size, cipherBytes.size)
            FALLBACK_ENC_PREFIX + Base64.encodeToString(combined, Base64.NO_WRAP)
        } catch (_: Exception) {
            plainJson
        }
    }

    private fun decryptFallbackPayload(stored: String): String {
        if (!stored.startsWith(FALLBACK_ENC_PREFIX)) {
            return stored
        }
        return try {
            val raw = Base64.decode(stored.removePrefix(FALLBACK_ENC_PREFIX), Base64.NO_WRAP)
            if (raw.size <= 12) return "[]"
            val iv = raw.copyOfRange(0, 12)
            val cipherBytes = raw.copyOfRange(12, raw.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, getOrCreateFallbackAesKey(), GCMParameterSpec(128, iv))
            String(cipher.doFinal(cipherBytes), Charsets.UTF_8)
        } catch (e: Exception) {
            Log.w("StreamX", "Fallback profile decrypt warning: ${e.message}")
            "[]"
        }
    }

    @Synchronized
    fun all(): MutableList<PlaylistProfile> {
        cachedProfiles?.let { return it.toMutableList() }
        if (!fastMetaPrefs.getBoolean("has_saved_profiles", true)) {
            val empty = mutableListOf<PlaylistProfile>()
            cachedProfiles = empty
            return mutableListOf()
        }
        val rawStored = try {
            securePrefs.getString("profiles", "[]") ?: "[]"
        } catch (e: Exception) {
            Log.w("StreamX", "Failed to read saved profiles")
            "[]"
        }
        val raw = if (rawStored.startsWith(FALLBACK_ENC_PREFIX)) {
            decryptFallbackPayload(rawStored)
        } else {
            rawStored
        }
        val parsed = try {
            val arr = JSONArray(raw)
            MutableList(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                PlaylistProfile(
                    id = sanitizeExternalInput(o.optString("id")).ifBlank { UUID.randomUUID().toString() },
                    name = sanitizeExternalInput(o.optString("name", "IPTV Account")).ifBlank { "IPTV Account" },
                    type = runCatching { ProfileType.valueOf(o.optString("type", "M3U")) }.getOrDefault(ProfileType.M3U),
                    source = sanitizeExternalInput(o.optString("source")),
                    username = sanitizeExternalInput(o.optString("username")),
                    password = sanitizeExternalInput(o.optString("password"))
                )
            }
        } catch (e: Exception) {
            Log.w("StreamX", "Corrupted profile JSON; resetting in-memory list")
            mutableListOf()
        }
        cachedProfiles = parsed
        fastMetaPrefs.edit().putBoolean("has_saved_profiles", parsed.isNotEmpty()).apply()
        return parsed.toMutableList()
    }

    @Synchronized
    fun save(profile: PlaylistProfile) {
        val cleanProfile = profile.copy(
            name = sanitizeExternalInput(profile.name).ifBlank { "IPTV Account" },
            source = sanitizeExternalInput(profile.source),
            username = sanitizeExternalInput(profile.username),
            password = sanitizeExternalInput(profile.password)
        )
        val list = all()
        val idx = list.indexOfFirst { it.id == cleanProfile.id }
        if (idx >= 0) list[idx] = cleanProfile else list.add(cleanProfile)
        persist(list)
    }

    @Synchronized
    fun delete(id: String) {
        val scope = normalizeScope(id)
        cachedProgressByScope.remove(scope)
        fastMetaPrefs.edit()
            .remove("$PLAYBACK_PROGRESS_PREFIX$scope")
            .remove("$MOVIE_WATCHLIST_PREFIX$scope")
            .remove("$SERIES_WATCHLIST_PREFIX$scope")
            .remove("$LIVE_FAVORITES_PREFIX$scope")
            .remove("$WATCHED_HISTORY_PREFIX$scope")
            .remove("$HIDDEN_CHANNELS_PREFIX$scope")
            .remove("$CUSTOM_CHANNEL_NAMES_PREFIX$scope")
            .remove("$CUSTOM_GROUPS_PREFIX$scope")
            .remove("$EPG_REMINDERS_PREFIX$scope")
            .apply()
        persist(all().filterNot { it.id == id })
    }

    fun activeId(): String? = try {
        fastMetaPrefs.getString("active_profile_id_fast", null)
            ?: if (fastMetaPrefs.getBoolean("has_saved_profiles", false)) securePrefs.getString("active_id", null) else null
    } catch (e: Exception) {
        Log.w("StreamX", "Failed to read active profile ID")
        null
    }

    fun setActive(id: String) {
        try {
            fastMetaPrefs.edit().putString("active_profile_id_fast", id).apply()
            if (fastMetaPrefs.getBoolean("has_saved_profiles", false)) {
                securePrefs.edit().putString("active_id", id).apply()
            }
        } catch (e: Exception) {
            Log.w("StreamX", "Failed to save active profile ID")
        }
    }

    // Salted SHA-256 4-Digit Parental PIN Lock with Legacy Compatibility
    fun hasParentalPin(): Boolean {
        val hash = fastMetaPrefs.getString(PIN_HASH_KEY, "") ?: ""
        if (hash.isNotBlank()) return true
        val legacy = fastMetaPrefs.getString(LEGACY_PIN_KEY, "") ?: ""
        return legacy.length == 4
    }

    fun getParentalPin(): String {
        return if (hasParentalPin()) "****" else ""
    }

    fun verifyParentalPin(candidatePin: String): Boolean {
        val trimmed = candidatePin.trim()
        if (trimmed.length != 4) return false
        val savedHash = fastMetaPrefs.getString(PIN_HASH_KEY, "") ?: ""
        val savedSalt = fastMetaPrefs.getString(PIN_SALT_KEY, "") ?: ""
        if (savedHash.isNotBlank() && savedSalt.isNotBlank()) {
            return verifySaltedPinHash(trimmed, savedSalt, savedHash)
        }
        val legacyPin = fastMetaPrefs.getString(LEGACY_PIN_KEY, "") ?: ""
        if (legacyPin.length == 4 && legacyPin == trimmed) {
            setParentalPin(trimmed)
            return true
        }
        return false
    }

    fun setParentalPin(pin: String) {
        val clean = pin.trim()
        if (clean.isEmpty()) {
            fastMetaPrefs.edit()
                .remove(PIN_HASH_KEY)
                .remove(PIN_SALT_KEY)
                .remove(LEGACY_PIN_KEY)
                .apply()
            return
        }
        val saltBytes = ByteArray(16)
        SecureRandom().nextBytes(saltBytes)
        val saltHex = saltBytes.joinToString("") { "%02x".format(it) }
        val hashHex = computeSaltedPinHash(clean, saltHex)
        fastMetaPrefs.edit()
            .putString(PIN_SALT_KEY, saltHex)
            .putString(PIN_HASH_KEY, hashHex)
            .remove(LEGACY_PIN_KEY)
            .apply()
    }

    fun getLockedCategories(): Set<String> {
        return fastMetaPrefs.getStringSet("locked_categories", emptySet())?.toSet() ?: emptySet()
    }

    fun toggleCategoryLock(category: String): Boolean {
        val norm = category.trim()
        val current = getLockedCategories().toMutableSet()
        val nowLocked = if (current.contains(norm)) {
            current.remove(norm)
            false
        } else {
            current.add(norm)
            true
        }
        fastMetaPrefs.edit().putStringSet("locked_categories", current).apply()
        return nowLocked
    }

    fun isCategoryLocked(category: String): Boolean {
        if (!hasParentalPin()) return false
        val norm = category.trim()
        if (getLockedCategories().any { it.equals(norm, ignoreCase = true) }) return true
        val lower = norm.lowercase(Locale.ROOT)
        return lower.contains("adult") || lower.contains("18+") || lower.contains("xxx")
    }

    fun getPreferredAudioLanguage(channelId: String): String? {
        return fastMetaPrefs.getString("audio_lang_$channelId", null)?.takeIf { it.isNotBlank() }
    }

    fun setPreferredAudioLanguage(channelId: String, language: String) {
        fastMetaPrefs.edit().putString("audio_lang_$channelId", language.trim()).apply()
    }

    // =========================================================================
    // v18.1 SMART CONTINUE WATCHING & WATCHED HISTORY (VOD & SERIES ONLY)
    // =========================================================================

    @Synchronized
    private fun ensureProgressLoaded(accountScope: String? = null): MutableMap<String, PlaybackProgressEntry> {
        val scope = normalizeScope(accountScope)
        cachedProgressByScope[scope]?.let { return it }
        val raw = fastMetaPrefs.getString("$PLAYBACK_PROGRESS_PREFIX$scope", "") ?: ""
        val map = LinkedHashMap<String, PlaybackProgressEntry>(64)
        if (raw.isNotBlank()) {
            for (line in raw.lineSequence()) {
                if (line.isBlank()) continue
                val parts = line.split('\t')
                if (parts.size >= 4) {
                    val id = parts[0]
                    val pos = parts[1].toLongOrNull() ?: 0L
                    val dur = parts[2].toLongOrNull() ?: 0L
                    val ts = parts[3].toLongOrNull() ?: 0L
                    val sKey = parts.getOrNull(4).orEmpty()
                    val sNum = parts.getOrNull(5)?.toIntOrNull() ?: 0
                    val eNum = parts.getOrNull(6)?.toIntOrNull() ?: 0
                    val cType = ContentSourceType.fromCode(
                        parts.getOrNull(7).orEmpty().ifBlank {
                            if (sKey.isNotBlank() || id.startsWith("ep_")) ContentSourceType.XTREAM_SERIES_EPISODE.code
                            else ContentSourceType.XTREAM_VOD_MOVIE.code
                        }
                    )
                    if (id.isNotBlank() && pos > 0L && !cType.isLiveTv()) {
                        map[id] = PlaybackProgressEntry(id, pos, dur, ts, cType, sKey, sNum, eNum)
                    }
                }
            }
        }
        cachedProgressByScope[scope] = map
        return map
    }

    /**
     * Saves playback progress ONLY for VOD Movies and Series Episodes.
     * Live TV channels (`M3U_LIVE`, `XTREAM_LIVE`) are strictly rejected so they never enter Continue Watching.
     */
    @Synchronized
    fun savePlaybackProgress(
        contentId: String,
        positionMs: Long,
        durationMs: Long,
        seriesKey: String = "",
        seasonNumber: Int = 0,
        episodeNumber: Int = 0,
        contentType: ContentSourceType = if (seriesKey.isNotBlank() || contentId.startsWith("ep_")) {
            ContentSourceType.XTREAM_SERIES_EPISODE
        } else {
            ContentSourceType.XTREAM_VOD_MOVIE
        },
        accountScope: String? = null
    ) {
        if (contentId.isBlank() || contentType.isLiveTv()) return
        val scope = normalizeScope(accountScope)
        val map = ensureProgressLoaded(scope)
        if (durationMs > 0L && (positionMs * 100L / durationMs) >= 95L) {
            map.remove(contentId)
            markContentWatched(contentId, scope)
        } else if (positionMs < 10_000L) {
            map.remove(contentId)
        } else {
            map[contentId] = PlaybackProgressEntry(
                contentId = contentId,
                positionMs = positionMs,
                durationMs = durationMs.coerceAtLeast(0L),
                updatedAtMs = System.currentTimeMillis(),
                contentType = contentType,
                seriesKey = seriesKey,
                seasonNumber = seasonNumber,
                episodeNumber = episodeNumber
            )
        }
        persistProgressMap(scope, map)
    }

    @Synchronized
    fun getPlaybackProgress(contentId: String, accountScope: String? = null): PlaybackProgressEntry? {
        if (contentId.isBlank()) return null
        return ensureProgressLoaded(accountScope)[contentId]
    }

    @Synchronized
    fun getContinueWatchingEntries(accountScope: String? = null): List<PlaybackProgressEntry> {
        return ensureProgressLoaded(accountScope)
            .values
            .filter { it.isResumable() && !it.contentType.isLiveTv() }
            .sortedByDescending { it.updatedAtMs }
    }

    @Synchronized
    fun clearPlaybackProgress(contentId: String, accountScope: String? = null) {
        val scope = normalizeScope(accountScope)
        val map = ensureProgressLoaded(scope)
        if (map.remove(contentId) != null) {
            persistProgressMap(scope, map)
        }
    }

    @Synchronized
    fun clearAllContinueWatching(accountScope: String? = null) {
        val scope = normalizeScope(accountScope)
        val map = ensureProgressLoaded(scope)
        map.clear()
        fastMetaPrefs.edit().remove("$PLAYBACK_PROGRESS_PREFIX$scope").apply()
    }

    private fun persistProgressMap(scope: String, map: MutableMap<String, PlaybackProgressEntry>) {
        val sorted = map.values.sortedByDescending { it.updatedAtMs }.take(MAX_PROGRESS_ITEMS)
        map.clear()
        val sb = StringBuilder(sorted.size * 56)
        for (entry in sorted) {
            map[entry.contentId] = entry
            sb.append(entry.contentId.replace('\t', ' ').replace('\n', ' '))
                .append('\t')
                .append(entry.positionMs)
                .append('\t')
                .append(entry.durationMs)
                .append('\t')
                .append(entry.updatedAtMs)
                .append('\t')
                .append(entry.seriesKey.replace('\t', ' ').replace('\n', ' '))
                .append('\t')
                .append(entry.seasonNumber)
                .append('\t')
                .append(entry.episodeNumber)
                .append('\t')
                .append(entry.contentType.code)
                .append('\n')
        }
        fastMetaPrefs.edit().putString("$PLAYBACK_PROGRESS_PREFIX$scope", sb.toString()).apply()
    }

    fun getWatchedContentIds(accountScope: String? = null): Set<String> {
        val scope = normalizeScope(accountScope)
        return fastMetaPrefs.getStringSet("$WATCHED_HISTORY_PREFIX$scope", emptySet())?.toSet() ?: emptySet()
    }

    fun isContentWatched(contentId: String, accountScope: String? = null): Boolean {
        if (contentId.isBlank()) return false
        return getWatchedContentIds(accountScope).contains(contentId)
    }

    fun markContentWatched(contentId: String, accountScope: String? = null) {
        if (contentId.isBlank()) return
        val scope = normalizeScope(accountScope)
        val current = getWatchedContentIds(scope).toMutableSet()
        current.add(contentId)
        fastMetaPrefs.edit().putStringSet("$WATCHED_HISTORY_PREFIX$scope", current).apply()
        clearPlaybackProgress(contentId, scope)
    }

    fun markContentUnwatched(contentId: String, accountScope: String? = null) {
        if (contentId.isBlank()) return
        val scope = normalizeScope(accountScope)
        val current = getWatchedContentIds(scope).toMutableSet()
        if (current.remove(contentId)) {
            fastMetaPrefs.edit().putStringSet("$WATCHED_HISTORY_PREFIX$scope", current).apply()
        }
        clearPlaybackProgress(contentId, scope)
    }

    fun markSeasonWatched(episodeIds: Collection<String>, accountScope: String? = null) {
        val scope = normalizeScope(accountScope)
        val current = getWatchedContentIds(scope).toMutableSet()
        for (id in episodeIds) {
            if (id.isNotBlank()) {
                current.add(id)
                clearPlaybackProgress(id, scope)
            }
        }
        fastMetaPrefs.edit().putStringSet("$WATCHED_HISTORY_PREFIX$scope", current).apply()
    }

    fun markSeasonUnwatched(episodeIds: Collection<String>, accountScope: String? = null) {
        val scope = normalizeScope(accountScope)
        val current = getWatchedContentIds(scope).toMutableSet()
        for (id in episodeIds) {
            current.remove(id)
            clearPlaybackProgress(id, scope)
        }
        fastMetaPrefs.edit().putStringSet("$WATCHED_HISTORY_PREFIX$scope", current).apply()
    }

    fun clearWatchedHistory(accountScope: String? = null) {
        val scope = normalizeScope(accountScope)
        fastMetaPrefs.edit().remove("$WATCHED_HISTORY_PREFIX$scope").apply()
    }

    // =========================================================================
    // v18.1 PERSONAL WATCHLIST (SEPARATED MOVIES & SERIES, PER-ACCOUNT ISOLATED)
    // =========================================================================

    fun getMovieWatchlistIds(accountScope: String? = null): Set<String> {
        val scope = normalizeScope(accountScope)
        return fastMetaPrefs.getStringSet("$MOVIE_WATCHLIST_PREFIX$scope", emptySet())?.toSet() ?: emptySet()
    }

    fun toggleMovieWatchlist(movieId: String, sourceType: ContentSourceType = ContentSourceType.XTREAM_VOD_MOVIE, accountScope: String? = null): Boolean {
        if (movieId.isBlank() || sourceType != ContentSourceType.XTREAM_VOD_MOVIE) return false
        val scope = normalizeScope(accountScope)
        val key = "$MOVIE_WATCHLIST_PREFIX$scope"
        val current = getMovieWatchlistIds(scope).toMutableSet()
        val added = if (current.contains(movieId)) {
            current.remove(movieId)
            false
        } else {
            current.add(movieId)
            true
        }
        fastMetaPrefs.edit().putStringSet(key, current).apply()
        return added
    }

    fun isMovieInWatchlist(movieId: String, accountScope: String? = null): Boolean {
        if (movieId.isBlank()) return false
        return getMovieWatchlistIds(accountScope).contains(movieId)
    }

    fun getSeriesWatchlistIds(accountScope: String? = null): Set<String> {
        val scope = normalizeScope(accountScope)
        return fastMetaPrefs.getStringSet("$SERIES_WATCHLIST_PREFIX$scope", emptySet())?.toSet() ?: emptySet()
    }

    fun toggleSeriesWatchlist(seriesKeyOrId: String, sourceType: ContentSourceType = ContentSourceType.XTREAM_SERIES, accountScope: String? = null): Boolean {
        if (seriesKeyOrId.isBlank() || (sourceType != ContentSourceType.XTREAM_SERIES && sourceType != ContentSourceType.XTREAM_SERIES_EPISODE)) return false
        val scope = normalizeScope(accountScope)
        val key = "$SERIES_WATCHLIST_PREFIX$scope"
        val current = getSeriesWatchlistIds(scope).toMutableSet()
        val added = if (current.contains(seriesKeyOrId)) {
            current.remove(seriesKeyOrId)
            false
        } else {
            current.add(seriesKeyOrId)
            true
        }
        fastMetaPrefs.edit().putStringSet(key, current).apply()
        return added
    }

    fun isSeriesInWatchlist(seriesKeyOrId: String, accountScope: String? = null): Boolean {
        if (seriesKeyOrId.isBlank()) return false
        return getSeriesWatchlistIds(accountScope).contains(seriesKeyOrId)
    }

    // =========================================================================
    // v19.0 HIDDEN CHANNELS, CUSTOM CHANNEL NAMES, CUSTOM COLLECTIONS & EPG REMINDERS
    // =========================================================================

    fun getHiddenChannelIds(accountScope: String? = null): Set<String> {
        val scope = normalizeScope(accountScope)
        return fastMetaPrefs.getStringSet("$HIDDEN_CHANNELS_PREFIX$scope", emptySet())?.toSet() ?: emptySet()
    }

    fun toggleChannelHidden(channelId: String, accountScope: String? = null): Boolean {
        if (channelId.isBlank()) return false
        val scope = normalizeScope(accountScope)
        val key = "$HIDDEN_CHANNELS_PREFIX$scope"
        val current = getHiddenChannelIds(scope).toMutableSet()
        val nowHidden = if (current.contains(channelId)) {
            current.remove(channelId)
            false
        } else {
            current.add(channelId)
            true
        }
        fastMetaPrefs.edit().putStringSet(key, current).apply()
        return nowHidden
    }

    fun unhideAllChannels(accountScope: String? = null) {
        val scope = normalizeScope(accountScope)
        fastMetaPrefs.edit().remove("$HIDDEN_CHANNELS_PREFIX$scope").apply()
    }

    fun getCustomChannelNamesMap(accountScope: String? = null): Map<String, String> {
        val scope = normalizeScope(accountScope)
        val raw = fastMetaPrefs.getString("$CUSTOM_CHANNEL_NAMES_PREFIX$scope", "") ?: ""
        if (raw.isBlank()) return emptyMap()
        val map = LinkedHashMap<String, String>()
        for (line in raw.lineSequence()) {
            val idx = line.indexOf('\t')
            if (idx > 0) {
                val id = line.substring(0, idx).trim()
                val custom = line.substring(idx + 1).trim()
                if (id.isNotEmpty() && custom.isNotEmpty()) {
                    map[id] = custom
                }
            }
        }
        return map
    }

    fun setCustomChannelName(channelId: String, customName: String, accountScope: String? = null) {
        if (channelId.isBlank()) return
        val scope = normalizeScope(accountScope)
        val current = getCustomChannelNamesMap(scope).toMutableMap()
        val clean = sanitizeExternalInput(customName)
        if (clean.isEmpty()) {
            current.remove(channelId)
        } else {
            current[channelId] = clean
        }
        val serialized = current.entries.joinToString("\n") { "${it.key}\t${it.value.replace('\t', ' ').replace('\n', ' ')}" }
        fastMetaPrefs.edit().putString("$CUSTOM_CHANNEL_NAMES_PREFIX$scope", serialized).apply()
    }

    fun getCustomChannelGroups(accountScope: String? = null): Map<String, Set<String>> {
        val scope = normalizeScope(accountScope)
        val raw = fastMetaPrefs.getString("$CUSTOM_GROUPS_PREFIX$scope", "") ?: ""
        if (raw.isBlank()) return emptyMap()
        val result = LinkedHashMap<String, Set<String>>()
        for (line in raw.lineSequence()) {
            val parts = line.split('\t')
            if (parts.size >= 2) {
                val groupName = parts[0].trim()
                val ids = parts[1].split(',').map { it.trim() }.filter { it.isNotEmpty() }.toSet()
                if (groupName.isNotEmpty() && ids.isNotEmpty()) {
                    result[groupName] = ids
                }
            }
        }
        return result
    }

    fun addChannelToCustomGroup(groupName: String, channelId: String, accountScope: String? = null) {
        val cleanGroup = sanitizeExternalInput(groupName).replace('\t', ' ')
        if (cleanGroup.isBlank() || channelId.isBlank()) return
        val scope = normalizeScope(accountScope)
        val current = getCustomChannelGroups(scope).mapValues { it.value.toMutableSet() }.toMutableMap()
        val set = current.getOrPut(cleanGroup) { LinkedHashSet() }
        set.add(channelId)
        persistCustomChannelGroups(scope, current)
    }

    fun removeChannelFromCustomGroup(groupName: String, channelId: String, accountScope: String? = null) {
        val scope = normalizeScope(accountScope)
        val current = getCustomChannelGroups(scope).mapValues { it.value.toMutableSet() }.toMutableMap()
        val set = current[groupName] ?: return
        set.remove(channelId)
        if (set.isEmpty()) current.remove(groupName)
        persistCustomChannelGroups(scope, current)
    }

    fun deleteCustomChannelGroup(groupName: String, accountScope: String? = null) {
        val scope = normalizeScope(accountScope)
        val current = getCustomChannelGroups(scope).mapValues { it.value.toMutableSet() }.toMutableMap()
        if (current.remove(groupName) != null) {
            persistCustomChannelGroups(scope, current)
        }
    }

    private fun persistCustomChannelGroups(scope: String, groups: Map<String, Set<String>>) {
        val serialized = groups.entries
            .filter { it.key.isNotBlank() && it.value.isNotEmpty() }
            .joinToString("\n") { "${it.key}\t${it.value.joinToString(",")}" }
        fastMetaPrefs.edit().putString("$CUSTOM_GROUPS_PREFIX$scope", serialized).apply()
    }

    fun getEpgReminders(accountScope: String? = null): List<String> {
        val scope = normalizeScope(accountScope)
        val raw = fastMetaPrefs.getString("$EPG_REMINDERS_PREFIX$scope", "") ?: ""
        return raw.lines().map { it.trim() }.filter { it.isNotEmpty() }
    }

    fun addEpgReminder(channelName: String, programmeTitle: String, timeWindow: String, accountScope: String? = null) {
        val scope = normalizeScope(accountScope)
        val entry = "${channelName.trim()} • ${programmeTitle.trim()} (${timeWindow.trim().ifBlank { "Upcoming" }})"
        val current = getEpgReminders(scope).toMutableList()
        current.removeAll { it.equals(entry, ignoreCase = true) }
        current.add(0, entry)
        fastMetaPrefs.edit().putString("$EPG_REMINDERS_PREFIX$scope", current.take(25).joinToString("\n")).apply()
    }

    fun clearEpgReminders(accountScope: String? = null) {
        val scope = normalizeScope(accountScope)
        fastMetaPrefs.edit().remove("$EPG_REMINDERS_PREFIX$scope").apply()
    }

    // =========================================================================
    // v19.0 LIVE TV BACKGROUND MANAGEMENT, PLAYER, DISPLAY & REMOTE SETTINGS
    // =========================================================================

    fun isStopLiveTvInBackgroundEnabled(): Boolean {
        return fastMetaPrefs.getBoolean(STOP_LIVE_BG_KEY, true)
    }

    fun setStopLiveTvInBackgroundEnabled(enabled: Boolean) {
        fastMetaPrefs.edit().putBoolean(STOP_LIVE_BG_KEY, enabled).apply()
    }

    fun isAutoReconnectLiveTvOnReturnEnabled(): Boolean {
        return fastMetaPrefs.getBoolean(AUTO_RECONNECT_LIVE_RETURN_KEY, false)
    }

    fun setAutoReconnectLiveTvOnReturnEnabled(enabled: Boolean) {
        fastMetaPrefs.edit().putBoolean(AUTO_RECONNECT_LIVE_RETURN_KEY, enabled).apply()
    }

    fun getSeekStepMs(): Long {
        return fastMetaPrefs.getLong(SEEK_STEP_MS_KEY, 15_000L).coerceIn(5_000L, 60_000L)
    }

    fun setSeekStepMs(stepMs: Long) {
        fastMetaPrefs.edit().putLong(SEEK_STEP_MS_KEY, stepMs.coerceIn(5_000L, 60_000L)).apply()
    }

    fun getVodPlaybackSpeed(): Float {
        return fastMetaPrefs.getFloat(VOD_SPEED_KEY, 1.0f).coerceIn(0.5f, 2.0f)
    }

    fun setVodPlaybackSpeed(speed: Float) {
        fastMetaPrefs.edit().putFloat(VOD_SPEED_KEY, speed.coerceIn(0.5f, 2.0f)).apply()
    }

    fun getUiDensityMode(): UiDensityMode {
        return UiDensityMode.fromId(fastMetaPrefs.getString(UI_DENSITY_KEY, null))
    }

    fun setUiDensityMode(mode: UiDensityMode) {
        fastMetaPrefs.edit().putString(UI_DENSITY_KEY, mode.id).apply()
    }

    fun getOverscanMarginDp(): Int {
        return fastMetaPrefs.getInt(OVERSCAN_MARGIN_DP_KEY, 0).coerceIn(0, 32)
    }

    fun setOverscanMarginDp(marginDp: Int) {
        fastMetaPrefs.edit().putInt(OVERSCAN_MARGIN_DP_KEY, marginDp.coerceIn(0, 32)).apply()
    }

    fun is24HourClockEnabled(): Boolean {
        return fastMetaPrefs.getBoolean(CLOCK_24H_KEY, false)
    }

    fun set24HourClockEnabled(enabled: Boolean) {
        fastMetaPrefs.edit().putBoolean(CLOCK_24H_KEY, enabled).apply()
    }

    fun isHighContrastTextEnabled(): Boolean {
        return fastMetaPrefs.getBoolean(HIGH_CONTRAST_KEY, false)
    }

    fun setHighContrastTextEnabled(enabled: Boolean) {
        fastMetaPrefs.edit().putBoolean(HIGH_CONTRAST_KEY, enabled).apply()
    }

    fun getIdleScreensaverMinutes(): Int {
        return fastMetaPrefs.getInt(SCREENSAVER_MINS_KEY, 10).coerceIn(0, 60)
    }

    fun setIdleScreensaverMinutes(minutes: Int) {
        fastMetaPrefs.edit().putInt(SCREENSAVER_MINS_KEY, minutes.coerceIn(0, 60)).apply()
    }

    fun getStartupDestination(): String {
        return fastMetaPrefs.getString(STARTUP_DEST_KEY, "LIVE_TV") ?: "LIVE_TV"
    }

    fun setStartupDestination(dest: String) {
        fastMetaPrefs.edit().putString(STARTUP_DEST_KEY, dest).apply()
    }

    fun getLongPressOkAction(): String {
        return fastMetaPrefs.getString(LONG_PRESS_OK_KEY, "QUICK_MENU") ?: "QUICK_MENU"
    }

    fun setLongPressOkAction(action: String) {
        fastMetaPrefs.edit().putString(LONG_PRESS_OK_KEY, action).apply()
    }

    fun isHomePersonalizationEnabled(): Boolean {
        return fastMetaPrefs.getBoolean(PERSONALIZATION_KEY, true)
    }

    fun setHomePersonalizationEnabled(enabled: Boolean) {
        fastMetaPrefs.edit().putBoolean(PERSONALIZATION_KEY, enabled).apply()
    }

    fun isSetupWizardCompleted(): Boolean {
        return fastMetaPrefs.getBoolean(SETUP_WIZARD_DONE_KEY, false)
    }

    fun setSetupWizardCompleted(done: Boolean) {
        fastMetaPrefs.edit().putBoolean(SETUP_WIZARD_DONE_KEY, done).apply()
    }

    fun isAutoNextEpisodeEnabled(): Boolean {
        return fastMetaPrefs.getBoolean(AUTO_NEXT_EPISODE_KEY, true)
    }

    fun setAutoNextEpisodeEnabled(enabled: Boolean) {
        fastMetaPrefs.edit().putBoolean(AUTO_NEXT_EPISODE_KEY, enabled).apply()
    }

    fun getSearchHistory(): List<String> {
        val raw = fastMetaPrefs.getString(SEARCH_HISTORY_KEY, "") ?: ""
        return raw.lines().map { it.trim() }.filter { it.isNotEmpty() }.take(MAX_SEARCH_HISTORY)
    }

    fun addSearchHistoryQuery(query: String) {
        val clean = sanitizeExternalInput(query)
        if (clean.length < 2) return
        val current = getSearchHistory().toMutableList()
        current.removeAll { it.equals(clean, ignoreCase = true) }
        current.add(0, clean)
        val trimmed = current.take(MAX_SEARCH_HISTORY)
        fastMetaPrefs.edit().putString(SEARCH_HISTORY_KEY, trimmed.joinToString("\n")).apply()
    }

    fun clearSearchHistory() {
        fastMetaPrefs.edit().remove(SEARCH_HISTORY_KEY).apply()
    }

    fun getPerformanceMode(isLowRamDevice: Boolean): PerformanceMode {
        val savedId = fastMetaPrefs.getString(PERFORMANCE_MODE_KEY, null)
        return PerformanceMode.fromId(savedId, isLowRamDevice)
    }

    fun setPerformanceMode(mode: PerformanceMode) {
        fastMetaPrefs.edit().putString(PERFORMANCE_MODE_KEY, mode.id).apply()
    }

    fun restoreDefaultSettingsPreservingProfilesAndCatalogs() {
        fastMetaPrefs.edit()
            .putBoolean(AUTO_NEXT_EPISODE_KEY, true)
            .putBoolean(STOP_LIVE_BG_KEY, true)
            .putBoolean(AUTO_RECONNECT_LIVE_RETURN_KEY, false)
            .putLong(SEEK_STEP_MS_KEY, 15_000L)
            .putFloat(VOD_SPEED_KEY, 1.0f)
            .putString(UI_DENSITY_KEY, UiDensityMode.STANDARD.id)
            .putInt(OVERSCAN_MARGIN_DP_KEY, 0)
            .putBoolean(CLOCK_24H_KEY, false)
            .putBoolean(HIGH_CONTRAST_KEY, false)
            .putInt(SCREENSAVER_MINS_KEY, 10)
            .putString(STARTUP_DEST_KEY, "LIVE_TV")
            .putString(LONG_PRESS_OK_KEY, "QUICK_MENU")
            .putBoolean(PERSONALIZATION_KEY, true)
            .putInt(AUDIO_BOOST_DB_KEY, 0)
            .putString(PICTURE_MODE_KEY, "STANDARD")
            .apply()
    }

    // =========================================================================
    // v19.2 AUDIO LOUDNESS BOOST, PICTURE MODE & PINNED CHANNELS
    // =========================================================================

    fun getAudioBoostDb(): Int {
        return fastMetaPrefs.getInt(AUDIO_BOOST_DB_KEY, 0).coerceIn(0, 900)
    }

    fun setAudioBoostDb(millibels: Int) {
        fastMetaPrefs.edit().putInt(AUDIO_BOOST_DB_KEY, millibels.coerceIn(0, 900)).apply()
    }

    fun getPictureMode(): String {
        return fastMetaPrefs.getString(PICTURE_MODE_KEY, "STANDARD") ?: "STANDARD"
    }

    fun setPictureMode(mode: String) {
        fastMetaPrefs.edit().putString(PICTURE_MODE_KEY, mode).apply()
    }

    fun getPinnedChannelIds(accountScope: String? = null): List<String> {
        val scope = normalizeScope(accountScope)
        val raw = fastMetaPrefs.getString("$PINNED_CHANNELS_PREFIX$scope", "") ?: ""
        return raw.lines().map { it.trim() }.filter { it.isNotEmpty() }
    }

    fun togglePinnedChannel(channelId: String, accountScope: String? = null): Boolean {
        if (channelId.isBlank()) return false
        val scope = normalizeScope(accountScope)
        val current = getPinnedChannelIds(scope).toMutableList()
        val pinned = if (current.contains(channelId)) {
            current.remove(channelId)
            false
        } else {
            current.add(0, channelId)
            true
        }
        fastMetaPrefs.edit().putString("$PINNED_CHANNELS_PREFIX$scope", current.take(15).joinToString("\n")).apply()
        return pinned
    }

    fun isChannelPinned(channelId: String, accountScope: String? = null): Boolean {
        if (channelId.isBlank()) return false
        return getPinnedChannelIds(accountScope).contains(channelId)
    }

    @Synchronized
    private fun persist(list: List<PlaylistProfile>) {
        cachedProfiles = list.toMutableList()
        fastMetaPrefs.edit().putBoolean("has_saved_profiles", list.isNotEmpty()).apply()
        try {
            val arr = JSONArray()
            list.forEach { p ->
                arr.put(
                    JSONObject()
                        .put("id", p.id)
                        .put("name", p.name)
                        .put("type", p.type.name)
                        .put("source", p.source)
                        .put("username", p.username)
                        .put("password", p.password)
                )
            }
            val rawJson = arr.toString()
            val prefInstance = securePrefs
            val toStore = if (usingFallbackPrefs) encryptFallbackPayload(rawJson) else rawJson
            prefInstance.edit().putString("profiles", toStore).apply()
        } catch (e: Exception) {
            Log.w("StreamX", "Failed to persist profiles")
        }
    }
}
